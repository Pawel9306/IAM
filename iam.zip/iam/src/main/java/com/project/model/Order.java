package com.project.model;
import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="TORDER")
public class Order implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ORDER_ID")
	private int orderId;
	@ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY, targetEntity=System.class)
	@JoinColumn(name = "SYSTEM_ID", referencedColumnName = "SYSTEM_ID")
	private int systemId;
	@ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY, targetEntity=System.class)
	@JoinColumn(name = "SYSTEM_NAME", referencedColumnName = "system_name")
	private String systemName;
	@Column(name="ORDER_DATE")
	private String orderDate;
	@Column(name="STATUS")
	private String status;
	@Column(name="COMMENT")
	private String comment;
	@Column(name="APPROVED_BY_MANAGER")
	private String managerApproval;
	@Column(name="APPROVED_BY_ADMIN")
	private String adminApproval;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getManagerApproval() {
		return managerApproval;
	}
	public void setManagerApproval(String managerApproval) {
		this.managerApproval = managerApproval;
	}
	
	public String getAdminApproval() {
		return adminApproval;
	}
	public void setAdminApproval(String adminApproval) {
		this.adminApproval = adminApproval;
	}
	
}
	