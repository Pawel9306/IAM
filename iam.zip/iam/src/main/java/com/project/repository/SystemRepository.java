package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.project.model.System;

public interface SystemRepository extends CrudRepository<System, Integer> {

	@Query("select a.systemName from System a")
    public List<System> getAllSystemsName();
	
}
