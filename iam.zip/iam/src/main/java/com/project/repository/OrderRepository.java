package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Order;

@Repository
public interface OrderRepository extends CrudRepository<Order, Integer> {
	
	@Query("from Order a where a.status='Aktywny'")
    public List<Order> getAllActiveOrdersbyId();
	
}
