package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.model.Order;
import com.project.repository.OrderRepository;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
 
 @Autowired
 OrderRepository OrderRepository;

 @Override
 public List<Order> getAllOrders() {
  return (List<Order>) OrderRepository.findAll();
 }
 
 @Override
 public List<Order> getAllActiveOrdersbyId() {
  return (List<Order>) OrderRepository.getAllActiveOrdersbyId();
 }

 @Override
 public Order getOrderById(int orderId) {
  return OrderRepository.findById(orderId).get();
 }

 @Override
 public void saveOrUpdate(Order order) {
	 OrderRepository.save(order);
 }

 @Override
 public void deleteOrder(int orderId) {
	 OrderRepository.deleteById(orderId);
 }


}
