package com.project.service;

import java.util.List;

import com.project.model.Order;

public interface OrderService {

 public List<Order> getAllOrders();
 
 public Order getOrderById(int orderId);
 
 public void saveOrUpdate(Order order);
 
 public void deleteOrder(int orderId);
 
 public List<Order> getAllActiveOrdersbyId();

}
